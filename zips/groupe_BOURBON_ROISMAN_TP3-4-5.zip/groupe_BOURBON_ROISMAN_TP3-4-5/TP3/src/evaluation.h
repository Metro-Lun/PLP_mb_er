#pragma once
#include "parseur.h"

void evaluate(Expression expression);