# Bibliothèques
* <time.h> pour la gestion de la date et de l'heure.
* <stdlib.h> pour les définitions générales et les fonctions utilitaires.
* <ctype.h> pour les fonctions de manipulation de caractères, notamment `tolower()`.

# Références
*
*

# Difficulté
*

# Commentaires
* 
* 

