# Bibliothèques
* <stdlib.h> : pour les fonctions d'allocation de mémoire, de conversion et de gestion des processus.
* <stdio.h> : pour les fonctions d'entrée/sortie standard.
* <string.h> : pour les fonctions de manipulation de chaînes de caractères.
* <ctype.h> : pour les fonctions de manipulation de caractères.

# Références
* 
* 

# Difficulté
* Souci de traduction de l'ordre des opérandes dans la notation postfixée : 345*+ et 345+* donnaient le même résultat, par exemple

# Commentaires
* 
* 