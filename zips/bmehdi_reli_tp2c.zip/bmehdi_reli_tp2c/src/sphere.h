#ifndef SPHERE_H
#define SPHERE_H

// Fonction pour calculer le volume d'une sphère
float calculer_volume(float rayon);

// Fonction pour calculer la surface d'une sphère
float calculer_surface(float rayon);

#endif
