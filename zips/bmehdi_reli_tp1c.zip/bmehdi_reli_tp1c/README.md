# Bibliothèques
* `stdio.h` (entrées et sorties standard)
* `math.h` (pour M_PI)
* `limits.h` (pour les limites min et max de chaque type)
* `stdlib.h` (pour les conversions de chaînes de caractères)

# Références
* [Les limites des types](https://zestedesavoir.com/tutoriels/755/le-langage-c-1/notions-avancees/les-limites-des-types/#len-t%C3%AAte-limitsh)
* [Convertir décimal en binaire en langage C](https://waytolearnx.com/2019/08/convertir-decimal-en-binaire-en-langage-c.html)

# Difficulté
* non

# Commentaires
* non

