#include <stdio.h>

int main() {
    printf("Bonjour le Monde");
    return 0;
}