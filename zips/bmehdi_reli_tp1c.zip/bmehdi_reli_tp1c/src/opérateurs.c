#include <stdio.h>

int main() {
    int a = 16;
    int b = 3;

    printf("Addition: %d\n", a + b);
    printf("Soustraction: %d\n", a - b);
    printf("Multiplication: %d\n", a * b);
    printf("Division: %d\n", a / b);
    printf("Modulo: %d\n", a % b);
    printf("Egalité: %d\n", a == b);
    printf("Supérieur: %d\n", a > b);

    return 0;
}